const db = firebase.firestore();

const proyectContainer = document.getElementById("proyects-container");

const getProyects = () => db.collection('Proyectos').get();

const getProyect =(id) => db.collection('Proyectos').doc(id).get(); 

const onGetProyect = (callback) => db.collection('Proyectos').onSnapshot(callback);


window.addEventListener("DOMContentLoaded", async (e) =>{

  onGetProyect((querySnapshot)=> {
    proyectContainer.innerHTML = ` `;
    querySnapshot.forEach(doc => {
  
      const proyect = doc.data(); 
      proyect.id = doc.id;
  
      proyectContainer.innerHTML += `

        <div class="mb-3 proyects pics all ${proyect.categoria} 2 animation" >
            <div class="card mb-2  mb-3 pics border ">
            <div class="view overlay zoom">
              <img class="card-img-top img-fluid " src="${proyect.fileurl}" >
              <div class="mask flex-center">
                
              </div>
            </div>
                <div class="card-body">
                    <h3 class="card-title">${proyect.title}</h3>
                    <hr>
                    <p class="card-text text-muted font-weight-light">${proyect.description}</p>
                </div>
            </div>
        </div>`; 

      const btnCategorias = document.querySelectorAll(".filter");
      btnCategorias.forEach(btn =>{
        let selectedClass = "";

          btn.addEventListener('click', (e) =>{
            e.preventDefault();
            console.log(btn);
             const selectedClass = e.target.dataset.rel; 
             console.log(selectedClass);

             $("#proyects-container").fadeTo(100, 0.1); 
             $("#proyects-container .proyects").not("." + selectedClass).fadeOut().removeClass('animation'); 
          
             setTimeout(function () {
              $("." + selectedClass).fadeIn().addClass('animation');
              $("#proyects-container").fadeTo(300, 1); 
             });

          });
        });
    });

  });

});
